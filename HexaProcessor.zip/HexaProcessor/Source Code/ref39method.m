epsilon = 1e-3;

input_image = imread('lena.jpg');
size1 = size(input_image);
if length(size1) == 3
    input_image = rgb2gray(input_image);
end

im1 = input_image;
[M N] = size(im1);
if mod(M,2) == 0;    M1 = M+1; else M1 = M; end
if mod(N,2) == 0;    N1 = N+1; else N1 = N; end
im2 = zeros(M1+4,N1+4);
im2(3:M+2,3:N+2) = im1;
im2(1,:) = im2(3,:); im2(2,:) = im2(3,:);
im2(end-2,:) = im2(end-3,:); im2(end-1,:) = im2(end-3,:); im2(end,:) = im2(end-3,:);
im2(:,1) = im2(:,3); im2(:,2) = im2(:,3);
im2(:,end-2) = im2(:,end-3); im2(:,end-1) = im2(:,end-3); im2(:,end) = im2(:,end-3);
[M1 N1] = size(im2);
image = im2;

center = ((size(im2)+1)/2)';
center_matrix = [center(1);center(2)/2];
im_He = zeros(2*center(1)-1,center(2));
[Me, Ne] = size(im_He);

im_h = zeros((M1-1)/2,(N1-1)/2);

Indy = 0;
flag = 0;
for j = 1:2:N1-1
    
    if flag == 1
        flag = 0;
    else
        flag = 1;
    end
    
    Indy = Indy+1;
    Indx = 0;
    for i = 1+flag:2:M1-1
        Indx = Indx+1;
        im_h(Indx,Indy) = mean(mean(image(i:i+1,j:j+1)));
    end
end

[M1 N1] = size(im_h);

flag = 1;
for j = 1:N1
    
    if flag == 1
        flag = 0;
    else
        flag = 1;
    end
    
    for i = 1:M1
        im_He(2*i-flag,j) = im_h(i,j)+epsilon;
    end
end
im_He = im_He(5:end-4,5:end-4);
showHexImage(im_He);