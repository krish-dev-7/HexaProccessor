
function R = FoM(edge_place_matrix_original,edge_place_matrix_test)

alpha = 1/9;
orig_edge = edge_place_matrix_original(5:end-4,5:end-4);
test_edge = edge_place_matrix_test(5:end-4,5:end-4);
[M, N] = size(orig_edge);
I_I = sum(orig_edge(:));
I_A = sum(test_edge(:));
r = zeros(M,N);
c = r;
for i = 1:M
    r(i,:) = i;
end
for j = 1:N
    c(:,j) = j;
end

orig_edge = orig_edge+(orig_edge==0)*1e6;
R1 = 0;
t=0;
for m = 5:M-4
    for n = 3:N-2
        if test_edge(m,n) == 1
            t = t+1;
            d = sqrt(((r-m)/2).^2+((sqrt(0.75)*(c-n)).^2)).*orig_edge;
            if orig_edge(m,n)~=1
                d(m,n) = 1e6;
            end
            d1 = min(d(:));
            R1 = R1+(1/(1+alpha*d1^2));
        end
    end
end
R = (1/(max(I_I,I_A)))*R1;
    