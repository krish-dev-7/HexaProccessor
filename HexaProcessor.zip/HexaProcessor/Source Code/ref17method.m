                                                                                                                                                                                                                                                                                                                                                                clear all
close all
clc

epsilon = 1e-3;

input_image = imread('lena.jpg');
size1 = size(input_image);
if length(size1) == 3
    input_image = rgb2gray(input_image);
end

im1 = input_image;
[M, N] = size(im1);
if mod(M,2) == 0;    M1 = M+1; else M1 = M; end
if mod(N,2) == 0;    N1 = N+1; else N1 = N; end
im2 = zeros(M1+4,N1+4);
im2(3:M+2,3:N+2) = im1;
im2(1,:) = im2(3,:); im2(2,:) = im2(3,:);
im2(end-2,:) = im2(end-3,:); im2(end-1,:) = im2(end-3,:); im2(end,:) = im2(end-3,:);
im2(:,1) = im2(:,3); im2(:,2) = im2(:,3);
im2(:,end-2) = im2(:,end-3); im2(:,end-1) = im2(:,end-3); im2(:,end) = im2(:,end-3);
[M1, N1] = size(im2);

image = im2;
im_h = zeros(round((7/8)*M1)+1,round((7/9)*N1)+1);
im_VHS = zeros(2*(round((7/8)*M1)+1),round((7/9)*N1)+1);

%------------------- Virtual Hexagonal Structure method -------------------
im_7D = zeros(7*M1,7*N1);
for i = 1:M1
    for j = 1:N1
        im_7D(7*(i-1)+1:7*i,7*(j-1)+1:7*j) = image(i,j);
    end
end

mask = [0,0,1,1,1,1,1,0,0;...
        0,1,1,1,1,1,1,1,0;...
        0,1,1,1,1,1,1,1,0;...
        1,1,1,1,1,1,1,1,1;...
        1,1,1,1,1,1,1,1,1;...
        0,1,1,1,1,1,1,1,0;...
        0,1,1,1,1,1,1,1,0;...
        0,0,1,1,1,1,1,0,0];

flag = 0;
Indy = 0;
[M1 N1] = size(im_7D);
for j = 1:9:N1-9
    if flag == 4
        flag = 0;
    else
        flag = 4;
    end
    Indy = Indy+1;
    Indx = 0;
    for i = 1+flag:8:M1-8
        Indx = Indx+1;
        im_h(Indx,Indy) = (1/56)*sum(sum(im_7D(i:i+7,j:j+8).*mask))+epsilon;
    end
end

[M2 N2] = size(im_h);
flag = 1;
for j = 1:N2
    
    if flag == 1
        flag = 0;
    else
        flag = 1;
    end
    
    for i = 1:M2
        im_VHS(2*i-flag,j) = im_h(i,j)+epsilon;
    end
end
%im_VHS = im_VHS(5:end-4,5:end-4);
disp(FoM(edge(im_h, 'sobel'), edgeHex(im_VHS, 20)));
%edgeHex(im_VHS, 20)%

