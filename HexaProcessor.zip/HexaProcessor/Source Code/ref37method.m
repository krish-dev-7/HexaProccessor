epsilon = 1e-3;

input_image = imread('lena.jpg');
size1 = size(input_image);
if length(size1) == 3
    input_image = rgb2gray(input_image);
end

im1 = input_image;
[M N] = size(im1);
if mod(M,2) == 0;    M1 = M+1; else M1 = M; end
if mod(N,2) == 0;    N1 = N+1; else N1 = N; end
im2 = zeros(M1+4,N1+4);
im2(3:M+2,3:N+2) = im1;
im2(1,:) = im2(3,:); im2(2,:) = im2(3,:);
im2(end-2,:) = im2(end-3,:); im2(end-1,:) = im2(end-3,:); im2(end,:) = im2(end-3,:);
im2(:,1) = im2(:,3); im2(:,2) = im2(:,3);
im2(:,end-2) = im2(:,end-3); im2(:,end-1) = im2(:,end-3); im2(:,end) = im2(:,end-3);
[M1 N1] = size(im2);
image = im2;

center = ((size(im2)+1)/2)';
center_matrix = [2*center(1);center(2)];
im_Horn = zeros(4*center(1)-5,2*center(2));
[Me, Ne] = size(im_Horn);

flag = 0;
for j = 1:N1
    
    if flag == 1
        flag = 0;
    else
        flag = 1;
    end
    
    for i = 1:M1
        im_Horn(2*i-flag,j) = image(i,j)+epsilon;
    end
end
im_Horn = im_Horn(5:end-4,5:end-4);
showHexImage(im_Horn);