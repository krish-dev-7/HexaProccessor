epsilon = 1e-3;

input_image = imread('lena.jpg');
size1 = size(input_image);
if length(size1) == 3
    input_image = rgb2gray(input_image);
end

im1 = input_image;
[M,N] = size(im1);
if mod(M,2) == 0; M1 = M+1; else M1 = M; end
if mod(N,2) == 0; N1 = N+1; else N1 = N; end
im2 = zeros(M1+4,N1+4);
im2(3:M+2,3:N+2) = im1;
im2(1,:) = im2(3,:); im2(2,:) = im2(3,:);
im2(end-2,:) = im2(end-3,:);
im2(end-1,:) = im2(end-3,:);
im2(end,:) = im2(end-3,:);
im2(:,1) = im2(:,3);
im2(:,2) = im2(:,3);
im2(:,end-2) = im2(:,end-3);
im2(:,end-1) = im2(:,end-3);
im2(:,end) = im2(:,end-3);
[M1, N1] = size(im2);
image = im2;
im_h = zeros(round((7/8)*M1)+1,round((7/9)*N1)+1);
im_VHS = zeros(2*(round((7/8)*M1)+1),round((7/9)*N1)+1);

%------------------- Virtual Hexagonal Structure method -------------------
im_7D = zeros(7*M1,7*N1);
for i = 1:M1
    for j = 1:N1
        im_7D(7*(i-1)+1:7*i,7*(j-1)+1:7*j) = image(i,j);
    end
end

mask = [0,0,1,1,1,1,1,0,0;...
        0,1,1,1,1,1,1,1,0;...
        0,1,1,1,1,1,1,1,0;...
        1,1,1,1,1,1,1,1,1;...
        1,1,1,1,1,1,1,1,1;...
        0,1,1,1,1,1,1,1,0;...
        0,1,1,1,1,1,1,1,0;...
        0,0,1,1,1,1,1,0,0];

flag = 0;
Indy = 0;
[M1 N1] = size(im_7D);
for j = 1:9:N1-9
    if flag == 4
        flag = 0;
    else
        flag = 4;
    end
    Indy = Indy+1;
    Indx = 0;
    for i = 1+flag:8:M1-8
        Indx = Indx+1;
        im_h(Indx,Indy) = (1/56)*sum(sum(im_7D(i:i+7,j:j+8).*mask))+epsilon;
    end
end

[M2 N2] = size(im_h);
flag = 1;
for j = 1:N2
    
    if flag == 1
        flag = 0;
    else
        flag = 1;
    end
    
    for i = 1:M2
        im_VHS(2*i-flag,j) = im_h(i,j)+epsilon;
    end
end
im_VHS = im_VHS(5:end-4,5:end-4);
subplot(2,2,1)
showHexImage(im_VHS);

%37method%
epsilon = 1e-3;

input_image = imread('lena.jpg');
size1 = size(input_image);
if length(size1) == 3
    input_image = rgb2gray(input_image);
end

im1 = input_image;
[M N] = size(im1);
if mod(M,2) == 0;    M1 = M+1; else M1 = M; end
if mod(N,2) == 0;    N1 = N+1; else N1 = N; end
im2 = zeros(M1+4,N1+4);
im2(3:M+2,3:N+2) = im1;
im2(1,:) = im2(3,:); im2(2,:) = im2(3,:);
im2(end-2,:) = im2(end-3,:); im2(end-1,:) = im2(end-3,:); im2(end,:) = im2(end-3,:);
im2(:,1) = im2(:,3); im2(:,2) = im2(:,3);
im2(:,end-2) = im2(:,end-3); im2(:,end-1) = im2(:,end-3); im2(:,end) = im2(:,end-3);
[M1 N1] = size(im2);
image = im2;

center = ((size(im2)+1)/2)';
center_matrix = [2*center(1);center(2)];
im_Horn = zeros(4*center(1)-5,2*center(2));
[Me, Ne] = size(im_Horn);

flag = 0;
for j = 1:N1
    
    if flag == 1
        flag = 0;
    else
        flag = 1;
    end
    
    for i = 1:M1
        im_Horn(2*i-flag,j) = image(i,j)+epsilon;
    end
end
im_Horn = im_Horn(5:end-4,5:end-4);
subplot(2,2,2)
showHexImage(im_Horn);

%39method%
epsilon = 1e-3;

input_image = imread('lena.jpg');
size1 = size(input_image);
if length(size1) == 3
    input_image = rgb2gray(input_image);
end

im1 = input_image;
[M N] = size(im1);
if mod(M,2) == 0;    M1 = M+1; else M1 = M; end
if mod(N,2) == 0;    N1 = N+1; else N1 = N; end
im2 = zeros(M1+4,N1+4);
im2(3:M+2,3:N+2) = im1;
im2(1,:) = im2(3,:); im2(2,:) = im2(3,:);
im2(end-2,:) = im2(end-3,:); im2(end-1,:) = im2(end-3,:); im2(end,:) = im2(end-3,:);
im2(:,1) = im2(:,3); im2(:,2) = im2(:,3);
im2(:,end-2) = im2(:,end-3); im2(:,end-1) = im2(:,end-3); im2(:,end) = im2(:,end-3);
[M1 N1] = size(im2);
image = im2;

center = ((size(im2)+1)/2)';
center_matrix = [center(1);center(2)/2];
im_He = zeros(2*center(1)-1,center(2));
[Me, Ne] = size(im_He);

im_h = zeros((M1-1)/2,(N1-1)/2);

Indy = 0;
flag = 0;
for j = 1:2:N1-1
    
    if flag == 1
        flag = 0;
    else
        flag = 1;
    end
    
    Indy = Indy+1;
    Indx = 0;
    for i = 1+flag:2:M1-1
        Indx = Indx+1;
        im_h(Indx,Indy) = mean(mean(image(i:i+1,j:j+1)));
    end
end

[M1 N1] = size(im_h);

flag = 1;
for j = 1:N1
    
    if flag == 1
        flag = 0;
    else
        flag = 1;
    end
    
    for i = 1:M1
        im_He(2*i-flag,j) = im_h(i,j)+epsilon;
    end
end
im_He = im_He(5:end-4,5:end-4);
subplot(2,2,3)
showHexImage(im_He);

%proposed method%
a = 1;
epsilon = 1e-3;
r3 = sqrt(3);

input_image = imread('lena.jpg');
size1 = size(input_image);
if length(size1) == 3
    input_image = rgb2gray(input_image);
end

im1 = input_image;
[M,N] = size(im1);
if mod(M,2) == 0;    M1 = M+1; else M1 = M; end
if mod(N,2) == 0;    N1 = N+1; else N1 = N; end
im2 = zeros(M1+4,N1+4);
im2(3:M+2,3:N+2) = im1;
im2(1,:) = im2(3,:); im2(2,:) = im2(3,:);
im2(end-2,:) = im2(end-3,:); im2(end-1,:) = im2(end-3,:); im2(end,:) = im2(end-3,:);
im2(:,1) = im2(:,3); im2(:,2) = im2(:,3);
im2(:,end-2) = im2(:,end-3); im2(:,end-1) = im2(:,end-3); im2(:,end) = im2(:,end-3);
[M1 N1] = size(im2);

for i = 1:2*M1
    for j = 1:fix(2/r3*N1)
        if mod(i,2)==1 && mod(j,2)==1
            hex_cor1 = 1/r3+((j-1)/2)*(3/r3);
            hex_cor2 = i/2;
            x = fix (hex_cor1)+1;
            y = round (hex_cor2+epsilon);
            hex_int = 0;
            if y >= 2 && x > 2 && y < M1-1 && x < fix(2/r3*N1)-1
                for n = y-1:y+1
                    for m = x-1:x+1
                        dx = abs(m-hex_cor1);
                        dy = abs(n-hex_cor2);
                        if dx < 1/2+1/r3 && dx >= 1/2+1/(2*r3) && dy < 0.25 %Case 1
                            hex_int = hex_int+im2(n,m)*(r3*(1/r3+1/2-dx)^2);
                        elseif dx < a/2+a/r3 && dx >= a/2+a/(2*r3) && dy > 0.25 && dy < 0.75 %Case 2
                            hex_int = hex_int+0.5*im2(n,m)*(r3*(a/r3+a/2-dx)^2);
                        elseif dx < 1/2+a/(2*r3) && dx >= 1/2-1/(2*r3) && dy < 0.25 %Case 3
                            hex_int = hex_int+im2(n,m)*(r3/4+1/2-dx);
                        elseif dx < 1/2+1/(2*r3) && dx >= 1/2-1/(2*r3) && dy > 0.25 && dy < 0.75 %Case 4
                            hex_int = hex_int+0.5*im2(n,m)*(r3/4+1/2-dx);
                        elseif dx < 1/2-1/(2*r3) && dx >= a/r3-a/2 && dy < 0.25 %Case 5
                            hex_int = hex_int+im2(n,m)*(1/2+r3/4-dx-r3*(1/2-1/(2*r3)-dx)^2);
                        elseif dx < a/2-a/(2*r3) && dx >= a/r3-a/2 && dy > 0.25 && dy < 0.75 %Case 6
                            hex_int = hex_int+0.5*im2(n,m)*(1/2+r3/4-dx-r3*(1/2-1/(2*r3)-dx)^2);
                        elseif dx < r3/2-1/2 && dy < 0.25 %Case 7
                            hex_int = hex_int+im2(n,m)*(1-r3*((1/2-1/(2*r3)-dx)^2+(1/2-1/(2*r3)+dx)^2));
                        elseif dx < r3/2-1/2 && dy > 0.25 && dy < 0.75 %Case 8
                            hex_int = hex_int+0.5*im2(n,m)*(1-r3*((1/2-1/(2*r3)-dx)^2+(1/2-1/(2*r3)+dx)^2));
                        end
                    end
                end
            end
        end
        if mod(i,2)==1 && mod(j,2)==0
            hex_int = 0;
        end
        if mod(i,2)==0 && mod(j,2)==0
            hex_cor1 = 5/(2*r3)+((j-2)/2)*(3/r3);
            hex_cor2 = i/2;
            x = fix (hex_cor1);
            y = round (hex_cor2+epsilon);
            hex_int = 0;
            if y >= 2 && x > 2 && y <= M1-1 && x <= fix(2/r3*N1)-1
                for n = y-1:y+1
                    for m = x-1:x+1
                        dx = abs(m-hex_cor1);
                        dy = abs(n-hex_cor2);
                        if dx < 1/2+1/r3 && dx >= 1/2+1/(2*r3) && dy < 0.25 %Case 1
                            hex_int = hex_int+im2(n,m)*(r3*(1/r3+1/2-dx)^2);
                        elseif dx < a/2+a/r3 && dx >= a/2+a/(2*r3) && dy > 0.25 && dy < 0.75 %Case 2
                            hex_int = hex_int+0.5*im2(n,m)*(r3*(a/r3+a/2-dx)^2);
                        elseif dx < a/2+a/(2*r3) && dx >= a/2-a/(2*r3) && dy < 0.25 %Case 3
                            hex_int = hex_int+im2(n,m)*(r3/4+a/2-dx);
                        elseif dx < a/2+a/(2*r3) && dx >= a/2-a/(2*r3) && dy > 0.25 && dy < 0.75 %Case 4
                            hex_int = hex_int+0.5*im2(n,m)*(r3/4+a/2-dx);
                        elseif dx < a/2-a/(2*r3) && dx >= a/r3-a/2 && dy < 0.25 %Case 5
                            hex_int = hex_int+im2(n,m)*(1/2+r3/4-dx-r3*(1/2-1/(2*r3)-dx)^2);
                        elseif dx < a/2-a/(2*r3) && dx >= a/r3-a/2 && dy > 0.25 && dy < 0.75 %Case 6
                            hex_int = hex_int+0.5*im2(n,m)*(1/2+r3/4-dx-r3*(1/2-1/(2*r3)-dx)^2);
                        elseif dx < r3/2-1/2 && dy < 0.25 %Case 7
                            hex_int = hex_int+im2(n,m)*(1-r3*((1/2-1/(2*r3)-dx)^2+(1/2-1/(2*r3)+dx)^2));
                        elseif dx < r3/2-1/2 && dy > 0.25 && dy < 0.75 %Case 8
                            hex_int = hex_int+0.5*im2(n,m)*(1-r3*((1/2-1/(2*r3)-dx)^2+(1/2-1/(2*r3)+dx)^2));
                        end
                    end
                end
            end
        end
        if mod(i,2)==0 && mod(j,2)==1
            hex_int = 0;
        end
        hex_int = hex_int*2/r3;
        im_out(i,j) = hex_int;
    end
end
outputHexImage = im_out(6:end-5,6:end-5);
subplot(2,2,4)
showHexImage(outputHexImage);