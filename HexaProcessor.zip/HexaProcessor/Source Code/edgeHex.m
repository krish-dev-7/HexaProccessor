
function edge_place_image = edgeHex(hex_image, Thr)
image = hex_image;
[M,N] = size(image);

edge_image = zeros(M,N);
f1 = 0.147;
f2 = 0.295;
for m = 5:M-4
    for n = 3:N-2
        if image(m,n)~=0
            I = image(m,n);
            I1 = image(m+2,n);
            I2 = image(m+1,n-1);
            I3 = image(m-1,n-1);
            I4 = image(m-2,n);
            I5 = image(m-1,n+1);
            I6 = image(m+1,n+1);
            G1 = f1*abs(I1-I2)+f2*abs(I6-I3)+f1*abs(I5-I4);
            G2 = f1*abs(I2-I3)+f2*abs(I1-I4)+f1*abs(I6-I5);
            G3 = f1*abs(I4-I3)+f2*abs(I5-I2)+f1*abs(I6-I1);
            G = (2/sqrt(3))*sqrt(G1^2+G2^2+G3^2);
            if G > Thr 
                edge_image(m,n) = 255;
            else
                edge_image(m,n) = 1;
            end
        end
    end
end
edge_place_image = (edge_image==255);
showHexImage(edge_place_image);