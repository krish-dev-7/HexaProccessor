
function im_out = showHexImage(image)

im = image;
[M, N] = size(im);
M1 = M/2;
N1 = N;
im_hex2squ = zeros(8*M1+8,7*N1+7);
mask = [0,0,1,1,1,1,1,0,0;...
        0,1,1,1,1,1,1,1,0;...
        0,1,1,1,1,1,1,1,0;...
        1,1,1,1,1,1,1,1,1;...
        1,1,1,1,1,1,1,1,1;...
        0,1,1,1,1,1,1,1,0;...
        0,1,1,1,1,1,1,1,0;...
        0,0,1,1,1,1,1,0,0];
    
for m = 1:M
    for n = 1:N
        if im(m,n)~=0
            corx = 4+(m-1)*4;
            cory = 5+(n-1)*7;            
            im_hex2squ(corx-3:corx+4,cory-4:cory+4) = ...
                im_hex2squ(corx-3:corx+4,cory-4:cory+4)+im(m,n)*mask;
        end
    end
end
im_out = im_hex2squ;
imshow(im_out,[])